package com.xenoage.player.musicxml.note;

import com.xenoage.player.MusicDataElement;
import com.xenoage.player.util.XMLReader;

import org.w3c.dom.Element;


/**
 * Backup element (version 1.1).
 * 
 * The elements footnote and level are ignored.
 *
 * @author Andreas Wenger
 */
public class Backup
implements MusicDataElement
{
  
  private Duration duration;
  
  
  public Backup(Element e)
  {
    duration = new Duration(XMLReader.element(e, "duration"));
  }


  public Duration getDuration()
  {
    return duration;
  }
  
  
  public void setDuration(Duration duration)
  {
    this.duration = duration;
  }

}
