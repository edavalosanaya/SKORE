package com.xenoage.player;

import com.xenoage.player.musicxml.MusicXMLDocument;
import com.xenoage.player.util.io.iocontext.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

import java.net.URL;


/**
 * The applet version of the Xenoage Player.
 * 
 * Java 1.5.0 or later is required.
 *
 * @author Andreas Wenger
 */
public class PlayerApplet
  extends JApplet
{

  private JLabel textBox;
  private JButton btnOpen;
  private JButton btnPlay;
  private JButton btnPause;
  private JButton btnStop;
  private JButton btnInfo;
  private ImageIcon[][] imgButtons;

  private Player player;
  private MusicXMLDocument doc;


  @Override public void init()
  {
    this.setSize(384, 36);
    
    player = new Player(this);

    //load background color
    try
    {
      String col = this.getParameter("bgcolor").toLowerCase();
      if (!col.startsWith("#"))
        col = "#" + col;
      getContentPane().setBackground(Color.decode(col));
    }
    catch (Exception e)
    {
      getContentPane().setBackground(Color.WHITE);
    }

    setLayout(null);

    //load background image
    ImageIcon img = null;
    try
    {
      img = loadSkinImage("frame.png");
    }
    catch (Exception ex)
    {
      MsgBox("Could not load skin - is the skin archive in the classpath?\n" +
        "Please read the readme.txt for more information.",
        JOptionPane.ERROR_MESSAGE);
      ex.printStackTrace();
      return;
    }

    //load button graphics
    imgButtons = new ImageIcon[2][5];
    imgButtons[0][0] = loadSkinImage("open.png");
    imgButtons[1][0] = loadSkinImage("open2.png");
    imgButtons[0][1] = loadSkinImage("play.png");
    imgButtons[1][1] = loadSkinImage("play2.png");
    imgButtons[0][2] = loadSkinImage("pause.png");
    imgButtons[1][2] = loadSkinImage("pause2.png");
    imgButtons[0][3] = loadSkinImage("stop.png");
    imgButtons[1][3] = loadSkinImage("stop2.png");
    imgButtons[0][4] = loadSkinImage("info.png");
    imgButtons[1][4] = loadSkinImage("info2.png");

    btnOpen = new JButton(imgButtons[0][0]);
    btnOpen.setBounds(47, 9, 18, 18);
    add(btnOpen);
    class BtnOpenListener
      extends MouseAdapter
      implements MouseListener
    {

      @Override public void mouseClicked(MouseEvent e)
      {
        String filename = "";
        try
        {
          textBox.setText("Please wait while loading...");
          
          String paramFiles = getParameter("files");
          if (paramFiles == null)
          {
            MsgBox("Could not find the files-parameter.\n" +
              "Please read the readme.txt for more information.",
              JOptionPane.ERROR_MESSAGE);
          }
          String[] files = paramFiles.split(";");
          filename = (String) JOptionPane.showInputDialog(null, "Select MusicXML file:",
            "Open file", JOptionPane.PLAIN_MESSAGE, null, files, files[0]);
          if (filename != null)
          {
            openFile(filename);
          }
          else
          {
            textBox.setText(Player.APP_TITLE);
          }
        }
        catch (Exception ex)
        {
          MsgBox(ex.toString(), JOptionPane.ERROR_MESSAGE);
          ex.printStackTrace();
        }
      }


      @Override public void mousePressed(MouseEvent e)
      {
        btnOpen.setIcon(imgButtons[1][0]);
      }


      @Override public void mouseReleased(MouseEvent e)
      {
        btnOpen.setIcon(imgButtons[0][0]);
      }
    }
    btnOpen.addMouseListener(new BtnOpenListener());


    btnPlay = new JButton(imgButtons[0][1]);
    btnPlay.setBounds(68, 9, 18, 18);
    add(btnPlay);
    class BtnPlayListener
      extends MouseAdapter
      implements MouseListener
    {

      @Override public void mouseClicked(MouseEvent e)
      {
        player.play();
      }


      @Override public void mousePressed(MouseEvent e)
      {
        btnPlay.setIcon(imgButtons[1][1]);
      }


      @Override public void mouseReleased(MouseEvent e)
      {
        btnPlay.setIcon(imgButtons[0][1]);
      }

    }
    btnPlay.addMouseListener(new BtnPlayListener());

    btnPause = new JButton(imgButtons[0][2]);
    btnPause.setBounds(89, 9, 18, 18);
    add(btnPause);
    class BtnPauseListener
      extends MouseAdapter
      implements MouseListener
    {

      @Override public void mouseClicked(MouseEvent e)
      {
        player.pause();
      }


      @Override public void mousePressed(MouseEvent e)
      {
        btnPause.setIcon(imgButtons[1][2]);
      }


      @Override public void mouseReleased(MouseEvent e)
      {
        btnPause.setIcon(imgButtons[0][2]);
      }

    }
    btnPause.addMouseListener(new BtnPauseListener());

    btnStop = new JButton(imgButtons[0][3]);
    btnStop.setBounds(110, 9, 18, 18);
    add(btnStop);
    class BtnStopListener
      extends MouseAdapter
      implements MouseListener
    {

      @Override public void mouseClicked(MouseEvent e)
      {
        player.stop();
      }


      @Override public void mousePressed(MouseEvent e)
      {
        btnStop.setIcon(imgButtons[1][3]);
      }


      @Override public void mouseReleased(MouseEvent e)
      {
        btnStop.setIcon(imgButtons[0][3]);
      }

    }
    btnStop.addMouseListener(new BtnStopListener());

    btnInfo = new JButton(imgButtons[0][4]);
    btnInfo.setBounds(361, 9, 18, 18);
    add(btnInfo);
    class BtnInfoListener
      extends MouseAdapter
      implements MouseListener
    {

      @Override public void mouseClicked(MouseEvent e)
      {
        InfoWindow frmInfo = new InfoWindow();
        frmInfo.setInformation(doc);
        frmInfo.setActivePage(0);
        frmInfo.setConsoleOutput(player.getConsoleOutput());
        frmInfo.setVisible(true);
      }


      @Override public void mousePressed(MouseEvent e)
      {
        btnInfo.setIcon(imgButtons[1][4]);
      }


      @Override public void mouseReleased(MouseEvent e)
      {
        btnInfo.setIcon(imgButtons[0][4]);
      }

    }
    btnInfo.addMouseListener(new BtnInfoListener());

    textBox = new JLabel(Player.APP_TITLE);
    textBox.setBounds(131, 9, 225, 18);
    textBox.setOpaque(false);
    textBox.setFont(new Font("Dialog", Font.PLAIN, 12));
    add(textBox);
    
    JLabel imgFrame = new JLabel(img);
    imgFrame.setBounds(0, 0, getWidth(), getHeight());
    add(imgFrame);
    
    //if start-argument was set, try to open that file
    String paramStart = this.getParameter("start");
    try
    {
      if (paramStart != null && paramStart.length() > 0)
        openFile(paramStart);
    }
    catch (Exception ex)
    {
      textBox.setText("Could not load \"" + paramStart + "\"!");
      ex.printStackTrace();
      JOptionPane.showMessageDialog(this,
        "Could not load \"" + paramStart + "\"!\n\n" + ex.toString());
    }
  }


  @Override public void destroy()
  {
    try
    {
      player.stop();
      player = null;
    }
    catch (Exception ex)
    {
    }
    super.destroy();
  }
  
  
  private ImageIcon loadSkinImage(String filename)
  {
    URL url = getClass().getResource("/data/applet/" + filename);
    return new ImageIcon(url);
  }
  
  
  private void MsgBox(String Msg, int MsgType)
  {
    JOptionPane.showMessageDialog(this, Msg, Player.APP_TITLE, MsgType);
  }


  /**
   * Opens the file with the given filename.
   */
  private void openFile(String filename) throws Exception
  {
    String filePath = getCodeBase().toExternalForm();
    if (getParameter("path") != null)
    {
      String p = getParameter("path");
      if (!p.endsWith("/"))
        p += "/";
      filePath += p;
    }
    showStatus(filename);
    
    doc = player.openDocument(
      new URLIOContext(new URL(filePath)), filename, this);
    
    if (doc != null)
    {
      player.openDocument(doc);
      textBox.setText(MusicXMLDocumentInfo.getScoreTitle(doc));
    }
  }
  

}
