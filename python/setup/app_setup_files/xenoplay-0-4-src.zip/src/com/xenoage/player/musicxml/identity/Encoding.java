package com.xenoage.player.musicxml.identity;

import com.xenoage.player.util.Parser;
import com.xenoage.player.util.XMLReader;

import java.util.*;

import org.w3c.dom.Element;


/**
 * Encoding of a MusicXML file (version 1.1).
 * 
 * The supports-Element is not supported.
 * Only one element of encoding-date and software,
 * respectively, are supported.
 *
 * @author Andreas Wenger
 */
public class Encoding
{
  
  private Date encodingDate;
  private ArrayList<Encoder> encoders;
  private String software;
  private ArrayList<String> encodingDescriptions;
  
  
  public Encoding(Element e)
  {
    //encoding-date
    Element eEncodingDate = XMLReader.element(e, "encoding-date");
    String sEncodingDate = XMLReader.textTrim(eEncodingDate);
    encodingDate = Parser.parseDate(sEncodingDate, "yyyy-MM-dd");
    //encoders
    encoders = new ArrayList<Encoder>();
    List<Element> eEncoders = XMLReader.elements(e, "encoder");
    for (Element eEncoder : eEncoders)
    {
      encoders.add(new Encoder(eEncoder));
    }
    //software
    Element eSoftware = XMLReader.element(e, "software");
    software = XMLReader.textTrim(eSoftware);
    //encoding-description
    encodingDescriptions = new ArrayList<String>();
    List<Element> eEncodingDescs = XMLReader.elements(e, "encoding-description");
    for (Element eEncodingDesc : eEncodingDescs)
    {
      encodingDescriptions.add(XMLReader.textTrim(eEncodingDesc));
    }
  }


  public List<Encoder> getEncoders()
  {
    return encoders;
  }


  
  public Date getEncodingDate()
  {
    return encodingDate;
  }


  public List<String> getEncodingDescriptions()
  {
    return encodingDescriptions;
  }

  
  /**
   * Gets the name of the encoding software, or null
   * if not set.
   */
  public String getSoftware()
  {
    return software;
  }

  
}
