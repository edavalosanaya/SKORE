package com.xenoage.player.musicxml;

import com.xenoage.player.util.XMLReader;
import com.xenoage.player.util.io.iocontext.*;

import java.io.*;

import java.util.ArrayList;
import java.util.List;
import java.util.jar.*;

import org.w3c.dom.Document;
import org.w3c.dom.Element;


/**
 * This class manages a MusicXML container,
 * that is a set of MusicXML documents packed
 * in a single .mxl file (like .zip),
 * introduced in MusicXML 2.0.
 *
 * @author Andreas Wenger
 */
public class MusicXMLContainer
{
  
  private static final String containerPath = "META-INF/container.xml";
  
  private JarIOContext ioContext;
  private ArrayList<String> files = new ArrayList<String>();
  
  
  /**
   * Opens the MusicXML container behind the given
   * JarIOContext.
   */
  public MusicXMLContainer(JarIOContext ioContext)
    throws IOException
  {
    this.ioContext = ioContext;
    openFromInputStream(ioContext.open());
  }
  
  
  /**
   * Reads the MusicXML container behind the given input stream,
   * for example from a .mxl file on a remote server.
   */
  private void openFromInputStream(InputStream in)
    throws IOException
  {
    //open the JAR input stream
    JarInputStream jarIS = null;
    try
    {
      jarIS = new JarInputStream(in);
    }
    catch (IOException ex)
    {
      throw new IOException("Invalid MusicXML container (" + ex.toString() + ")");
    }
    //look for "META-INF/container.xml"
    JarEntry entry = null, container = null;
    while ((entry = jarIS.getNextJarEntry()) != null)
    {
      if (entry.getName().equals(containerPath))
      {
        container = entry;
        break;
      }
    }
    if (container == null)
      throw new IOException("Container information is missing!");
    //read the file names from the container document
    Document doc = XMLReader.readFile(jarIS);
    Element root = XMLReader.root(doc);
    Element eRootfiles = XMLReader.element(root, "rootfiles");
    if (eRootfiles == null)
      throw new IOException("Element \"rootfiles\" is missing!");
    List<Element> eFiles = XMLReader.elements(eRootfiles, "rootfile");
    for (Element e : eFiles)
    {
      String filename = XMLReader.attribute(e, "full-path");
      if (filename != null)
        files.add(filename);
    }
  }

  
  public List<String> getFiles()
  {
    return files;
  }
  
  
  /**
   * Returns an JarContentIOContext for the Jar file within
   * this archive with the given filename.
   */
  public JarContentIOContext openInternJar(String filename)
    throws IOException
  {
    return ioContext.openJar(filename);
  }
  
  
  /**
   * Returns an InputStream for the file within
   * this archive with the given filename.
   */
  public InputStream openFile(String filename)
    throws IOException
  {
    return ioContext.openFile(filename);
  }
  

}
