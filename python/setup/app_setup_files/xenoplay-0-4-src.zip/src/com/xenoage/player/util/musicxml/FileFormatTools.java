package com.xenoage.player.util.musicxml;

import com.xenoage.player.util.XMLReader;

import org.w3c.dom.Document;
import org.w3c.dom.Element;


/**
 * This class contains useful functions for dealing
 * with MusicXML file formats.
 *
 * @author Andreas Wenger
 */
public class FileFormatTools
{
  
  public enum Format { XML, Compressed };
  public enum Type { Score, Opus, Unknown };
  
  
  /**
   * Returns the format of the given file.
   * TODO: this has to be improved
   */
  public static Format getFormat(String filename)
  {
    if (filename.toLowerCase().endsWith(".xml"))
      return Format.XML;
    else
      return Format.Compressed;
  }
  
  
  /**
   * Returns Type.Score, if the given document is a
   * score-partwise or score-timewise document, Type.Opus
   * if it is an opus document, otherwise Type.Unknown.
   */
  public static Type getType(Document doc)
  {
    Element root = XMLReader.root(doc);
    String name = root.getNodeName();
    if (name.equals("opus"))
      return Type.Opus;
    else if (name.equals("score-partwise") || name.equals("score-timewise"))
      return Type.Score;
    else
      return Type.Unknown;
  }
  

}
