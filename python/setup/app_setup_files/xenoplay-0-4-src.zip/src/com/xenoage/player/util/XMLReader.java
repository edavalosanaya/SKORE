package com.xenoage.player.util;

import java.io.*;
import java.util.*;

import javax.xml.parsers.*;

import org.w3c.dom.*;
import org.xml.sax.*;


/**
 * This class contains some helper functions
 * to parse XML files and read values
 * out of XML documents with JAXP.
 *
 * @author Andreas Wenger
 */
public class XMLReader
{

  
  /**
   * Reads and returns the XML document at the given path.
   */
  public static Document readFile(File file)
    throws ParserConfigurationException, SAXException, IOException
  {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = factory.newDocumentBuilder();
    builder.setEntityResolver(new NoResolver());
    return builder.parse(file);
  }
  
  
  /**
   * Reads and returns the XML document at the given input stream.
   */
  public static Document readFile(InputStream stream)
    throws IOException
  {
    try
    {
      DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
      DocumentBuilder builder = factory.newDocumentBuilder();
      builder.setEntityResolver(new NoResolver());
      return builder.parse(stream);
    }
    catch (Exception ex)
    {
      throw new IOException(ex.toString());
    }
  }
  
  
  /**
   * Reads and returns the XML document at the given URI.
   */
  public static Document readFile(String uri)
    throws ParserConfigurationException, SAXException, IOException
  {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = factory.newDocumentBuilder();
    builder.setEntityResolver(new NoResolver());
    return builder.parse(uri);
  }
  
  
  /**
   * Gets the root element of the given document.
   */
  public static Element root(Document doc)
  {
    return doc.getDocumentElement();
  }
  
  
  /**
   * Gets the text of the given element, or "".
   */
  public static String text(Element element)
  {
    if (element == null)
      return "";
    else
      return element.getTextContent();
  }
  
  
  /**
   * Gets the trimmed text of the given element, or "".
   */
  public static String textTrim(Element element)
  {
    if (element == null)
      return "";
    else
      return element.getTextContent().trim();
  }
  
  
  /**
   * Reads and returns the value of the attribute with the
   * given name of the given element, or null if not found.
   */
  public static String attribute(Element element, String name)
  {
    if (element == null) return null;
    NamedNodeMap attributes = element.getAttributes();
    if (attributes == null) return null;
    Node value = attributes.getNamedItem(name);
    if (value == null) return null;
    return value.getTextContent();
  }
  
  
  /**
   * Reads and returns the value of the attribute with the
   * given name of the given element, or "" if not found.
   */
  public static String attributeNotNull(Element element, String name)
  {
    String ret = attribute(element, name);
    if (ret == null)
      ret = "";
    return ret;
  }
  
  
  /**
   * Gets the first child element of the given node with
   * the given name, or null if not found.
   */
  public static Element element(Node parent, String name)
  {
    NodeList children = parent.getChildNodes();
    for (int i = 0; i < children.getLength(); i++)
    {
      if (children.item(i).getNodeName().equals(name))
        return (Element) children.item(i);
    }
    return null;
  }
  
  
  /**
   * Gets the a list of all child elements of the given node with
   * the given name. If no such elements are found, the returned
   * list is empty. 
   */
  public static List<Element> elements(Node parent, String name)
  {
    ArrayList<Element> ret = new ArrayList<Element>();
    NodeList children = parent.getChildNodes();
    for (int i = 0; i < children.getLength(); i++)
    {
      if (children.item(i).getNodeName().equals(name))
        ret.add((Element) children.item(i));
    }
    return ret;
  }
  
  
  /**
   * Gets the a list of all child elements of the given node.
   * If no elements are found, the returned
   * list is empty. 
   */
  public static List<Element> elements(Node parent)
  {
    ArrayList<Element> ret = new ArrayList<Element>();
    NodeList children = parent.getChildNodes();
    for (int i = 0; i < children.getLength(); i++)
    {
      if (children.item(i) instanceof Element)
        ret.add((Element) children.item(i));
    }
    return ret;
  }
  
  
  /**
   * Gets the text of the given child element with the given name
   * of the given parent element, or "".
   */
  public static String elementText(Element parentElement, String elementName)
  {
    return text(element(parentElement, elementName));
  }

}