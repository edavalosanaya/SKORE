package com.xenoage.player;

import com.xenoage.player.musicxml.MusicXMLDocument;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;


/**
 * This frame shows information on
 * the application and the open score.
 * 
 * @author Andreas Wenger
 */
public class InfoWindow
  extends JDialog
{

  TitledBorder titledBorder1;
  JPanel pnlMain = new JPanel();
  JPanel pnlApp = new JPanel();
  JPanel pnlConsole = new JPanel();


  JPanel pnlScore = new JPanel();
  JTabbedPane tabMain = new JTabbedPane();
  Border border1;
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel pnlButtons = new JPanel();
  JButton btnClose = new JButton();
  Border border2;
  Border border3;
  JScrollPane scroll_txtScore = new JScrollPane();
  JTextArea txtScore = new JTextArea();
  JScrollPane scroll_txtApp = new JScrollPane();
  JTextArea txtApp = new JTextArea();
  JScrollPane scroll_txtConsole = new JScrollPane();
  JTextArea txtConsole = new JTextArea();


  public InfoWindow(Frame frame, String title, boolean modal)
  {
    super(frame, title, modal);
    try
    {
      jbInit();
      pack();
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
  }


  public InfoWindow()
  {
    this(null, "", false);
    this.setLocationRelativeTo(null);
  }


  public void setActivePage(int TabIndex)
  {
    tabMain.setSelectedIndex(TabIndex);
  }


  public void setInformation(MusicXMLDocument doc)
  {

    //### score info ###

    String sScore = "";
    String sTemp = "";

    if (doc != null)
    {
      sTemp = MusicXMLDocumentInfo.getScoreTitle(doc);
      sScore += sTemp + "\n";
      for (int i = 0; i < sTemp.length(); i++)
        sScore += "*";
      sScore += "\n\n";

      sScore += fillWithSpaces("work-number:", 24)
        + MusicXMLDocumentInfo.getWorkNumber(doc) + "\n";
      sScore += fillWithSpaces("work-title:", 24)
        + MusicXMLDocumentInfo.getWorkTitle(doc) + "\n";
      sScore += fillWithSpaces("movement-number:", 24)
        + MusicXMLDocumentInfo.getMovementNumber(doc) + "\n";
      sScore += fillWithSpaces("movement-title:", 24)
        + MusicXMLDocumentInfo.getMovementTitle(doc) + "\n";
      sScore += "\n";

      sScore += "creators:\n";
      String sCreators[][] = MusicXMLDocumentInfo.getCreator(doc);
      if (sCreators != null)
      {
        for (int i = 0; i < sCreators[0].length; i++)
        {
          sScore += fillWithSpaces("   " + sCreators[0][i] + ":", 24) + sCreators[1][i]
            + "\n";
        }
      }
      else
        sScore += "   -\n";
      sScore += "\n";

      String sRights[] = MusicXMLDocumentInfo.getRights(doc);
      if (sRights != null)
      {
        sScore += fillWithSpaces("rights:", 24) + sRights[0] + "\n";
        for (int i = 1; i < sRights.length; i++)
        {
          sScore += fillWithSpaces("", 24) + sRights[i] + "\n";
        }
      }
      else
        sScore += fillWithSpaces("rights:", 24) + "-\n";

      sScore += fillWithSpaces("encoding-date:", 24)
        + MusicXMLDocumentInfo.getEncodingDate(doc) + "\n";
      sScore += fillWithSpaces("encoder:", 24) + MusicXMLDocumentInfo.getEncoder(doc)
        + "\n";
      sScore += fillWithSpaces("software:", 24) + MusicXMLDocumentInfo.getSoftware(doc)
        + "\n";
      sScore += fillWithSpaces("encoding-description:", 24)
        + MusicXMLDocumentInfo.getEncodingDescription(doc) + "\n";
      sScore += "\n";

      sScore += "parts:\n";
      String sPartNames[] = MusicXMLDocumentInfo.getPartNames(doc);
      if (sPartNames != null)
      {
        for (int i = 0; i < sPartNames.length; i++)
        {
          sScore += fillWithSpaces("   " + i + ":", 24) + sPartNames[i] + "\n";
        }
      }
      else
        sScore += "   -\n";
    }
    else
    {
      sScore = "No MusicXML file loaded.";
    }
    txtScore.setText(sScore);

    //### program info ###
    String sApp =
      Player.APP_TITLE + "\n" +
      "******************"
      + "\n\n" + fillWithSpaces("Version:", 16) + Player.APP_VERSION + "\n"
      + fillWithSpaces("Type:", 16) + "Java Application and Applet" + "\n"
      + fillWithSpaces("Java Version:", 16) + System.getProperty("java.version") + "\n\n"
      + fillWithSpaces("Description:", 16) + "This program plays MusicXML files" + "\n"
      + fillWithSpaces("", 16) + "and converts them to MIDI format." + "\n\n"
      + fillWithSpaces("Donations:", 16) + "This program is freeware." + "\n"
      + fillWithSpaces("", 16) + "If you want to support us, visit" + "\n"
      + fillWithSpaces("", 16) + "http://www.xenoage.com/donate/" + "\n\n"
      + fillWithSpaces("Copyright:", 16) + "(c) 2004-2007 by Andreas Wenger," + "\n"
      + fillWithSpaces("", 16) + "Xenoage Software, www.xenoage.com" + "\n\n"
      + "For more information, questions or suggestions" + "\n" + "visit our homepage:"
      + "\n" + "http://www.xenoage.com/mxmlplay/";
    txtApp.setText(sApp);
  }


  private String fillWithSpaces(String s, int len)
  {
    String res = s;
    for (int i = 0; i < len - s.length(); i++)
      res += " ";
    return res;
  }


  private void jbInit() throws Exception
  {
    titledBorder1 = new TitledBorder("");
    border1 = BorderFactory.createEmptyBorder(4, 4, 4, 4);
    border2 = BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(
      BevelBorder.LOWERED, Color.white, Color.white, new Color(124, 124, 124), new Color(
        178, 178, 178)), BorderFactory.createEmptyBorder(2, 2, 2, 2));
    border3 = BorderFactory.createEmptyBorder(0, 2, 0, 2);
    pnlMain.setBorder(border1);
    pnlMain.setMinimumSize(new Dimension(423, 379));
    pnlMain.setLayout(borderLayout1);
    this.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
    this.setModal(false);
    this.setResizable(false);
    this.setTitle(Player.APP_TITLE + " - Info");
    btnClose.setActionCommand("btnClose");
    btnClose.setText("Close");
    btnClose.addMouseListener(new InfoWindow_btnClose_mouseAdapter(this));
    txtScore.setFont(new java.awt.Font("Monospaced", 0, 12));
    txtScore.setBorder(border3);
    txtScore.setRequestFocusEnabled(true);
    txtScore.setVerifyInputWhenFocusTarget(true);
    txtScore.setEditable(false);
    txtScore.setMargin(new Insets(1, 1, 1, 1));
    txtScore.setText("");
    txtScore.setColumns(0);
    txtScore.setLineWrap(false);
    scroll_txtScore.setMaximumSize(new Dimension(400, 300));
    scroll_txtScore.setMinimumSize(new Dimension(400, 300));
    scroll_txtScore.setPreferredSize(new Dimension(400, 300));
    txtApp.setLineWrap(false);
    txtApp.setColumns(0);
    txtApp.setText("");
    txtApp.setMargin(new Insets(1, 1, 1, 1));
    txtApp.setEditable(false);
    txtApp.setVerifyInputWhenFocusTarget(true);
    txtApp.setRequestFocusEnabled(true);
    txtApp.setBorder(border3);
    txtApp.setFont(new java.awt.Font("Monospaced", 0, 12));
    scroll_txtApp.setMaximumSize(new Dimension(400, 300));
    scroll_txtApp.setMinimumSize(new Dimension(400, 300));
    scroll_txtApp.setPreferredSize(new Dimension(400, 300));
    txtConsole.setLineWrap(false);
    txtConsole.setColumns(0);
    txtConsole.setText("");
    txtConsole.setMargin(new Insets(1, 1, 1, 1));
    txtConsole.setEditable(false);
    txtConsole.setVerifyInputWhenFocusTarget(true);
    txtConsole.setRequestFocusEnabled(true);
    txtConsole.setBorder(border3);
    txtConsole.setFont(new java.awt.Font("Monospaced", 0, 12));
    scroll_txtConsole.setMaximumSize(new Dimension(400, 300));
    scroll_txtConsole.setMinimumSize(new Dimension(400, 300));
    scroll_txtConsole.setPreferredSize(new Dimension(400, 300));
    this.getContentPane().add(pnlMain, BorderLayout.NORTH);
    tabMain.add(pnlScore, "Score Info");
    pnlScore.add(scroll_txtScore, null);
    tabMain.add(pnlApp, "Program Info");
    pnlApp.add(scroll_txtApp, null);
    tabMain.add(pnlConsole, "Console");
    pnlConsole.add(scroll_txtConsole, null);
    scroll_txtApp.getViewport().add(txtApp, null);
    pnlMain.add(pnlButtons, BorderLayout.SOUTH);
    pnlMain.add(tabMain, BorderLayout.CENTER);
    pnlButtons.add(btnClose, null);
    scroll_txtScore.getViewport().add(txtScore, null);
    scroll_txtConsole.getViewport().add(txtConsole, null);
  }


  void btnClose_mouseClicked(MouseEvent e)
  {
    this.dispose();
  }
  
  
  public void setConsoleOutput(String consoleOutput)
  {
    txtConsole.setText(consoleOutput);
  }

}


class InfoWindow_btnClose_mouseAdapter
  extends java.awt.event.MouseAdapter
{

  InfoWindow adaptee;


  InfoWindow_btnClose_mouseAdapter(InfoWindow adaptee)
  {
    this.adaptee = adaptee;
  }


  @Override public void mouseClicked(MouseEvent e)
  {
    adaptee.btnClose_mouseClicked(e);
  }
}
