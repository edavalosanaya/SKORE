package com.xenoage.player.util.io.iocontext;

import java.io.*;


/**
 * IOContext for access to the contents
 * of a Jar document that is part of
 * another Jar document.
 * 
 * There is no public constructor, instead
 * the openInternJar method of the
 * JarFileIOContext, JarURLIOContext and
 * JarContentIOContext classes can be used.
 * 
 * The filenames are relative to the root
 * folder of the Jar document.
 *
 * @author Andreas Wenger
 */
public class JarContentIOContext
  extends JarIOContext
{
  
  private String parentJarFilename;
  private JarIOContext baseContext;
  
  
  
  /**
   * Creates an JarContentIOContext for the Jar document
   * with the given filename behind the given JarIOContext.
   */
  JarContentIOContext(String parentJarFilename, JarIOContext baseContext)
  {
    this.baseContext = baseContext;
    this.parentJarFilename = parentJarFilename;
  }
  
  
  /**
   * Opens an input stream for this Jar document.
   */
  @Override public InputStream open()
    throws IOException
  {
    return baseContext.openFile(parentJarFilename);
  }

}
