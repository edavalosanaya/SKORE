package com.xenoage.player.util.io.iocontext;

import java.io.*;
import java.net.URL;


/**
 * IOContext for access to URLs.
 * 
 * The context uses a given code base,
 * like "http://www.xenoage.com/dir/".
 * The filenames are relative to this base.
 *
 * @author Andreas Wenger
 */
public class URLIOContext
  implements IOContext
{
  
  private URL codeBase;
  
  
  /**
   * Creates an URLIOContext for the given code base.
   */
  public URLIOContext(URL codeBase)
  {
    this.codeBase = codeBase;
  }

  
  /**
   * Opens the file with the given filename
   * as an InputStream.
   * The filename is relative to the code base
   * of this context.
   */
  public InputStream openFile(String filename)
    throws IOException
  {
    URL url = new URL(codeBase, filename);
    return url.openStream();
  }
  
  
  /**
   * Creates a new JarIOContext from the Jar file
   * with the given filename.
   */
  public JarURLIOContext openJar(String filename)
    throws IOException
  {
    JarURLIOContext jarIO = new JarURLIOContext(
      new URL(codeBase, filename));
    return jarIO;
  }

}
