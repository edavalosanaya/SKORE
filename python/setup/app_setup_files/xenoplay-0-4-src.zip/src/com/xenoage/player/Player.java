package com.xenoage.player;

import com.xenoage.player.musicxml.MusicXMLContainer;
import com.xenoage.player.musicxml.MusicXMLDocument;
import com.xenoage.player.musicxml.opus.Opus;
import com.xenoage.player.musicxml.opus.OpusScore;
import com.xenoage.player.util.XMLReader;
import com.xenoage.player.util.io.iocontext.*;
import com.xenoage.player.util.musicxml.FileFormatTools;
import com.xenoage.player.util.musicxml.FileFormatTools.Format;
import com.xenoage.player.util.musicxml.FileFormatTools.Type;

import java.awt.Component;
import java.io.*;
import java.util.List;

import javax.sound.midi.*;
import javax.swing.*;

import org.w3c.dom.Document;


/**
 * This class manages the current MIDI sequence,
 * the sequencer and the synthesizer and
 * provides methods to play, pause and stop
 * the sequence and to change the volume.
 * 
 * It can be used by both the application and
 * the applet version of the Xenoage Player
 * and contains also some general GUI elements.
 *
 * @author Andreas Wenger
 */
public class Player
{
  
  public static final String APP_TITLE = "Xenoage Player 0.4";
  public static final String APP_VERSION = "0.4.2007.06.26";
  
  private Sequence seq;
  private Sequencer sequencer;
  private Synthesizer synthesizer;
  private float volume = 0.7f;
  
  private Component parentComponent;
  
  private StringBuilder consoleOutput;


  public Player(Component parentComponent)
  {
    this.parentComponent = parentComponent;
    
    consoleOutput = new StringBuilder();
    PrintStream out = new PrintStream(new StringOutputStream());
    try
    {
      System.setOut(out);
      System.setErr(out);
    }
    catch (Exception ex)
    {
      //may be blocked because of security reasons
      consoleOutput.append("Could not bind console output to application.");
    }
  
    try
    {
      //create synthesizer and sequencer
      sequencer = MidiSystem.getSequencer(false);
      synthesizer = MidiSystem.getSynthesizer();
      Transmitter seqTransmitter = sequencer.getTransmitter();
      seqTransmitter.setReceiver(synthesizer.getReceiver());
      synthesizer.open();
    }
    catch (Exception e)
    {
      MsgBox("Midi not available!", JOptionPane.ERROR_MESSAGE);
    }

  }


  public void openDocument(MusicXMLDocument doc)
  {
    try
    {
      seq = MusicXMLtoMIDI.convertMusicXMLtoMIDI(doc, this);
    }
    catch (Exception ex)
    {
      MsgBox("Could not convert MusicXML document!", JOptionPane.ERROR_MESSAGE);
      ex.printStackTrace();
    }
    
    try
    {
      sequencer.open();
      sequencer.stop();
      sequencer.setSequence(seq);
      setVolume(volume);
      sequencer.start();
    }
    catch (Exception ex)
    {
      MsgBox("Midi not available!", JOptionPane.ERROR_MESSAGE);
      ex.printStackTrace();
    }
  }


  public void MsgBox(String Msg, int MsgType)
  {
    JOptionPane.showMessageDialog(parentComponent, Msg, APP_TITLE, MsgType);
  }


  public String getTime(int time)
  {
    String mins, secs;
    mins = String.valueOf(time / 60);
    secs = String.valueOf(time % 60);
    if (secs.length() < 2)
      secs = "0" + secs;
    return mins + ":" + secs;
  }
  
  
  public float getVolume()
  {
    return volume;
  }


  /**
   * Sets the volume.
   * @param volume  value between 0 (silent) and 1 (loud)
   */
  public void setVolume(float volume)
  {
    this.volume = volume;
    MidiChannel[] channels = synthesizer.getChannels();
    
    //TODO: should be 127 (some websites say this)
    //but 255 is the real max volume! test it!
    int max = 255;
    
    for (int i = 0; i < channels.length; i++)
    {
      channels[i].controlChange(7, (int) (volume * max));
    }
  }
  
  
  public void play()
  {
    if (sequencer.getMicrosecondPosition() >= sequencer.getMicrosecondLength())
      sequencer.setMicrosecondPosition(0);
    setVolume(volume);
    sequencer.start();
  }
  
  
  public void pause()
  {
    sequencer.stop();
  }
  
  
  public void stop()
  {
    sequencer.stop();
    sequencer.setMicrosecondPosition(0);
  }
  
  
  public Sequencer getSequencer()
  {
    return sequencer;
  }
  
  
  public String getConsoleOutput()
  {
    return consoleOutput.toString();
  }
  
  
  private class StringOutputStream
    extends OutputStream
  {

    @Override public void write(int b)
    {
      char c = (char) b;
      consoleOutput.append(String.valueOf(c));
    }

  } 
  
  
  /**
   * Returns the MusicXMLDocument behind the
   * given file based on the given IOContext.
   * <ul>
   *   <li>If it is a XML-Score, this document is returned.</li>
   *   <li>If it is a MXL-Document with a XML-Score, the
   *       XML-Score is returned.</li>
   *   <li>If it is a XML-Opus or a MXL-Opus with a single Score,
   *       the single Score is returned.</li>
   *   <li>If it is a XML-Opus or a MXL-Opus with multiple Documents
   *       (scores and opera), the XML-Scores are recursively
   *       collected, then a dialog box is shown, where the user
   *       can select one of the scores from a list.</li>
   * </ul>
   */
  public MusicXMLDocument openDocument(IOContext baseContext, String filename,
    Component parentComponent)
    throws Exception
  {
    //XML or MXL?
    Format format = FileFormatTools.getFormat(filename);
    if (format == Format.XML)
    {
      //XML score or opus?
      Document doc = XMLReader.readFile(baseContext.openFile(filename));
      Type docType = FileFormatTools.getType(doc);
      if (docType == Type.Score)
      {
        //return the single file
        return new MusicXMLDocument(doc);
      }
      else if (docType == Type.Opus)
      {
        //opens the opus document and lets the user select one
        //of the files
        Opus opus = new Opus(doc, baseContext);
        return openOpusDocument(opus, parentComponent);
      }
      else
      {
        throw new IOException("Unknown document type: " +
          XMLReader.root(doc).getNodeName());
      }
    }
    else if (format == Format.Compressed)
    {
      //MXL score or opus?
      JarIOContext jarIO = baseContext.openJar(filename);
      MusicXMLContainer container = new MusicXMLContainer(jarIO);
      List<String> files = container.getFiles();
      if (files.size() == 0)
        throw new IOException("Container has no rootfile: " + filename);
      Document doc = XMLReader.readFile(container.openFile(files.get(0)));
      Type docType = FileFormatTools.getType(doc);
      if (docType == Type.Score)
      {
        //return the single file
        return new MusicXMLDocument(doc);
      }
      else if (docType == Type.Opus)
      {
        //opens the opus document and lets the user select one
        //of the files
        Opus opus = new Opus(doc, jarIO);
        return openOpusDocument(opus, parentComponent);
      }
      else
      {
        throw new IOException("Unknown document type: " +
          XMLReader.root(doc).getNodeName());
      }
    }
    else
    {
      throw new IOException("Unknown document format: " +
        filename);
    }
  }
  
  
  /**
   * Returns a MusicXMLDocument from the given opus.
   * <ul>
   *   <li>If it contains only one XML-Score, this document is returned.</li>
   *   <li>If it contains more than one XML-Score, a dialog with a list
   *       is shown, where the user selects one of the scores.</li>
   * </ul>
   */
  private MusicXMLDocument openOpusDocument(Opus opus, Component parentComponent)
    throws Exception
  {
    List<OpusScore> scores = opus.getScores();
    if (scores.size() == 0)
    {
      throw new IOException("Opus has no scores!");
    }
    else if (scores.size() == 1)
    {
      //only one score: open it without dialog
      Document doc = XMLReader.readFile(scores.get(0).open());
      return new MusicXMLDocument(doc);
    }
    else
    {
      //multiple scores: let the user select one
      Object[] aFiles = scores.toArray();
      OpusScore s = (OpusScore) JOptionPane.showInputDialog(
        parentComponent, "Please select the score:", Player.APP_TITLE,
        JOptionPane.QUESTION_MESSAGE, null,
        aFiles, aFiles[0]);
      if (s != null)
      {
        Document xmlDoc = XMLReader.readFile(s.open());
        return new MusicXMLDocument(xmlDoc);
      }
      else
      {
        //no selection: return the first score
        Document doc = XMLReader.readFile(scores.get(0).open());
        return new MusicXMLDocument(doc);
      }
    }
  }


}
