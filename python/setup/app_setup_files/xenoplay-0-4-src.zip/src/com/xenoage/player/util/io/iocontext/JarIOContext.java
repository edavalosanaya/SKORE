package com.xenoage.player.util.io.iocontext;

import java.io.*;
import java.util.jar.JarEntry;
import java.util.jar.JarInputStream;


/**
 * Abstract base class for IOContext implementations
 * that work with Jar files.
 *
 * @author Andreas Wenger
 */
public abstract class JarIOContext
  implements IOContext
{
  
  /**
   * Opens the file with the given filename
   * as an InputStream.
   * It is read from the given InputStream.
   */
  protected InputStream openFile(String filename, InputStream inputStream)
    throws IOException
  {
    JarInputStream jarIS = new JarInputStream(inputStream);
    JarEntry entry;
    while ((entry = jarIS.getNextJarEntry()) != null)
    {
      if (entry.getName().equals(filename))
      {
        return jarIS;
      }
    }
    throw new IOException("Jar entry \"" + filename + "\" not found!");
  }
  
  
  /**
   * Creates a new JarContentIOContext from the Jar file
   * with the given filename.
   * It is read from the given JarInputStream.
   * 
   * In other words, this method provides access to Jar
   * files within other Jar files.
   */
  public JarContentIOContext openJar(String filename)
  {
    JarContentIOContext ret = new JarContentIOContext(filename, this);
    return ret;
  }
  
  
  /**
   * Opens the file with the given filename
   * as an InputStream.
   * The filename is relative to the root folder
   * of the Jar file of this context.
   */
  public InputStream openFile(String filename)
    throws IOException
  {
    return openFile(filename, open());
  }
  
  
  /**
   * Opens an input stream for this Jar document.
   */
  public abstract InputStream open()
    throws IOException;

}
