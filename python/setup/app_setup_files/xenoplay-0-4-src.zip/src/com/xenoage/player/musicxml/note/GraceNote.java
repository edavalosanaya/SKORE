package com.xenoage.player.musicxml.note;

import com.xenoage.player.util.XMLReader;

import org.w3c.dom.Element;


/**
 * Grace note.
 * 
 * This class models the code
 * <code>
 * (grace, %full-note;, (tie, tie?)?)
 * </code>
 * in the note element in MusicXML 1.1.
 * 
 * The element tie is ignored.
 *
 * @author Andreas Wenger
 */
public class GraceNote
  implements NoteType
{
  
  private Grace grace;
  private Chord chord;
  private NotePitchType notePitchType;
  
  
  public GraceNote(Element e)
  {
    grace = new Grace(XMLReader.element(e, "grace"));
    if (XMLReader.element(e, "chord") != null)
      chord = new Chord();
    Element ePitch = XMLReader.element(e, "pitch");
    Element eUnpitched = XMLReader.element(e, "unpitched");
    Element eRest = XMLReader.element(e, "rest");
    if (ePitch != null)
      notePitchType = new Pitch(ePitch);
    else if (eUnpitched != null)
      notePitchType = new Unpitched();
    else if (eRest != null)
      notePitchType = new Rest();
  }
  
  
  public Grace getGrace()
  {
    return grace;
  }

  
  public Chord getChord()
  {
    return chord;
  }

  
  public NotePitchType getNotePitchType()
  {
    return notePitchType;
  }
  
  
  public Duration getDuration()
  {
    return null;
  }
  
  
  public void setDuration(Duration duration)
  {
  }
  

}
