package com.xenoage.player.musicxml.score;

import com.xenoage.player.util.XMLReader;

import org.w3c.dom.Element;


/**
 * Information about the work (version 1.1).
 * 
 * The opus element is not supported.
 *
 * @author Andreas Wenger
 */
public class Work
{
  
  private String workNumber;
  private String workTitle;
  
  
  public Work(Element e)
  {
    workNumber = XMLReader.elementText(e, "work-number");
    workTitle = XMLReader.elementText(e, "work-title");
  }
  
  
  /**
   * Gets the number of the work, or null if unknown.
   */
  public String getWorkNumber()
  {
    return workNumber;
  }
  
  
  /**
   * Gets the number of the work, or null if unknown.
   */
  public String getWorkTitle()
  {
    return workTitle;
  }
  

}
