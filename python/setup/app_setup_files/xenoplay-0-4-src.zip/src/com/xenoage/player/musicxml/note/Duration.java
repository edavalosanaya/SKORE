package com.xenoage.player.musicxml.note;

import com.xenoage.player.util.Parser;
import com.xenoage.player.util.XMLReader;

import org.w3c.dom.Element;


/**
 * Duration of a note or a rest (version 1.1).
 *
 * @author Andreas Wenger
 */
public class Duration
{
  
  private int value;
  
  
  public Duration(Element e)
  {
    value = Parser.parseInt(XMLReader.textTrim(e));
  }
  
  
  public Duration(int value)
  {
    this.value = value;
  }


  public int getValue()
  {
    return value;
  }
  

}
