package com.xenoage.player.util.io.iocontext;

import java.io.*;
import java.net.URL;


/**
 * IOContext for access to the contents
 * of a Jar document behind an URL.
 * 
 * The filenames are relative to the root
 * folder of the Jar document.
 *
 * @author Andreas Wenger
 */
public class JarURLIOContext
  extends JarIOContext
{
  
  private URL jarURL;
  
  
  /**
   * Creates an URLIOContext for the Jar document
   * behind the given URL.
   */
  public JarURLIOContext(URL jarURL)
  {
    this.jarURL = jarURL;
  }

  
  /**
   * Opens an input stream for this Jar document.
   */
  @Override public InputStream open()
    throws IOException
  {
    return jarURL.openStream();
  }

}
