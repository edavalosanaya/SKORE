package com.xenoage.player.musicxml.note;

import com.xenoage.player.util.Parser;
import com.xenoage.player.util.XMLReader;

import org.w3c.dom.Element;


/**
 * The grace element indicates the presence of
 * a grace note (version 1.1).
 *
 * @author Andreas Wenger
 */
public class Grace
{
  
  private Float stealTimePrevious;
  private Float stealTimeFollowing;
  private Float makeTime;
  
  
  public Grace(Element e)
  {
    stealTimePrevious = Parser.parseFloatNull(
      XMLReader.attribute(e, "steal-time-previous"));
    stealTimeFollowing = Parser.parseFloatNull(
      XMLReader.attribute(e, "steal-time-following"));
    makeTime = Parser.parseFloatNull(
      XMLReader.attribute(e, "make-time"));
  }
  
  
  public Float getStealTimePrevious()
  {
    return stealTimePrevious;
  }
  
  
  public Float getStealTimeFollowing()
  {
    return stealTimeFollowing;
  }


  public Float getMakeTime()
  {
    return makeTime;
  }


}
