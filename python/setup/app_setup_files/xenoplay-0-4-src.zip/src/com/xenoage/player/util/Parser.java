package com.xenoage.player.util;

import java.text.*;
import java.util.Date;


/**
 * Some useful methods for parsing.
 *
 * @author Andreas Wenger
 */
public class Parser
{
  
  private Parser()
  {
  }
  
  
  /**
   * Returns the int value of the given String,
   * or 0 if the conversion impossible.
   */
  public static int parseInt(String value)
  {
    try
    {
      return Integer.parseInt(value);
    }
    catch (Exception ex)
    {
      return 0;
    }
  }
  
  
  /**
   * Returns the float value of the given String,
   * or 0 if the conversion impossible.
   */
  public static float parseFloat(String value)
  {
    try
    {
      return Float.parseFloat(value);
    }
    catch (Exception ex)
    {
      return 0;
    }
  }
  
  
  /**
   * Returns the boolean value of the given String,
   * or false if the conversion impossible.
   */
  public static boolean parseBoolean(String value)
  {
    try
    {
      return Boolean.parseBoolean(value);
    }
    catch (Exception ex)
    {
      return false;
    }
  }
  
  
  /**
   * Returns the Integer value of the given String,
   * or null if the conversion impossible.
   */
  public static Integer parseIntegerNull(String value)
  {
    try
    {
      return Integer.parseInt(value);
    }
    catch (Exception ex)
    {
      return null;
    }
  }
  
  
  /**
   * Returns the Float value of the given String,
   * or null if the conversion impossible.
   */
  public static Float parseFloatNull(String value)
  {
    try
    {
      return Float.parseFloat(value);
    }
    catch (Exception ex)
    {
      return null;
    }
  }
  
  
  /**
   * Returns the Boolean value of the given String,
   * or null if the conversion impossible.
   */
  public static Boolean parseBooleanNull(String value)
  {
    try
    {
      return Boolean.parseBoolean(value);
    }
    catch (Exception ex)
    {
      return null;
    }
  }
  
  
  /**
   * Returns the Date value of the given String,
   * parsed with the given pattern, or null
   * is the conversion is impossible.
   */
  public static Date parseDate(String value, String pattern)
  {
    try
    {
      DateFormat fmt = new SimpleDateFormat(pattern);
      return fmt.parse(value);
    }
    catch (ParseException ex)
    {
      return null;
    }
  }

}
