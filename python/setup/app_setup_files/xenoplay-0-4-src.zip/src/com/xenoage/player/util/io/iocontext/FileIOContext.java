package com.xenoage.player.util.io.iocontext;

import java.io.*;


/**
 * IOContext for access to files.
 * 
 * The filenames are relative to the given
 * base directory.
 * 
 * Relative 
 *
 * @author Andreas Wenger
 */
public class FileIOContext
  implements IOContext
{
  
  private String baseDirectory;
  
  
  /**
   * Creates an FileIOContext for the given base
   * directory.
   */
  public FileIOContext(String baseDirectory)
  {
    this.baseDirectory = baseDirectory;
    if (!this.baseDirectory.endsWith("/") &&
      !this.baseDirectory.endsWith("\\"))
      this.baseDirectory += "/";
  }

  
  /**
   * Opens the file with the given filename
   * as an InputStream.
   */
  public InputStream openFile(String filename)
    throws IOException
  {
    File file = new File(baseDirectory + filename);
    return new FileInputStream(file);
  }
  
  
  /**
   * Creates a new JarIOContext from the Jar file
   * with the given filename.
   */
  public JarFileIOContext openJar(String filename)
  {
    JarFileIOContext jarIO = new JarFileIOContext(
      new File(baseDirectory + filename));
    return jarIO;
  }

}
