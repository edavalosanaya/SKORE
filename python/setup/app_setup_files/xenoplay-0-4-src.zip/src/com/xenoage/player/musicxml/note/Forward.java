package com.xenoage.player.musicxml.note;

import com.xenoage.player.MusicDataElement;
import com.xenoage.player.util.XMLReader;

import org.w3c.dom.Element;


/**
 * Forward element (version 1.1).
 * 
 * The elements footnote, level, voice and
 * staff are ignored.
 *
 * @author Andreas Wenger
 */
public class Forward
  implements MusicDataElement
{
  
  private Duration duration;
  
  
  public Forward(Element e)
  {
    duration = new Duration(XMLReader.element(e, "duration"));
  }


  public Duration getDuration()
  {
    return duration;
  }
  
  
  public void setDuration(Duration duration)
  {
    this.duration = duration;
  }

}
