package com.xenoage.player.musicxml.opus;

import com.xenoage.player.util.XMLReader;
import com.xenoage.player.util.io.iocontext.IOContext;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;


/**
 * This class models a MusicXML opus.
 * It can contain multiple scores and
 * also other opera.
 * 
 * This class is compatible to both
 * MusicXML 1.x and 2.0.
 *
 * @author Andreas Wenger
 */
public class Opus
  implements OpusChild
{
 
  private String title = null;
  private ArrayList<OpusChild> children = new ArrayList<OpusChild>();
  
  
  /**
   * Reads an opus from the given document.
   * For file references the given IOContext
   * is used.
   */
  public Opus(Document doc, IOContext ioContext)
    throws IOException, IllegalArgumentException
  {
    //read the opus element
    fromElement(XMLReader.root(doc), ioContext);
  }
  
  
  private Opus()
  {
  }
  
  
  
  /**
   * Reads an opus from the given XML element.
   * The given IOContext is used to open files
   * with relative addresses.
   */
  public void fromElement(Element eOpus, IOContext ioContext)
    throws IOException, IllegalArgumentException
  {
    //check for valid format
    if (!eOpus.getNodeName().equals("opus"))
    {
      throw new IllegalArgumentException("No valid opus document!");
    }
    //read title
    Element eTitle = XMLReader.element(eOpus, "title");
    if (eTitle != null)
      this.title = XMLReader.text(eTitle);
    //read children
    List<Element> listChildren = XMLReader.elements(eOpus);
    for (Element eChild : listChildren)
    {
      String name = eChild.getNodeName();
      if (name.equals("score"))
      {
        //child score
        OpusScore childScore = new OpusScore(eChild, ioContext);
        children.add(childScore);
      }
      else if (name.equals("opus"))
      {
        //child opus
        Opus childOpus = new Opus();
        fromElement(eChild, ioContext);
        children.add(childOpus);
      }
      else if (name.equals("opus-link"))
      {
        //link to child opus
        String filename = XMLReader.attribute(eChild, "xlink:href");
        if (filename != null)
        {
          InputStream in = ioContext.openFile(filename);
          Document doc = XMLReader.readFile(in);
          Opus childOpus = new Opus(doc, ioContext);
          children.add(childOpus);
        }
      }
    }
  }
  
  
  /**
   * Gets the list of all scores of this opus child
   * in the correct order.
   */
  public List<OpusScore> getScores()
  {
    ArrayList<OpusScore> ret = new ArrayList<OpusScore>();
    for (OpusChild child : children)
      ret.addAll(child.getScores());
    return ret;
  }


  
  public String getTitle()
  {
    return title;
  }
  
  
}
