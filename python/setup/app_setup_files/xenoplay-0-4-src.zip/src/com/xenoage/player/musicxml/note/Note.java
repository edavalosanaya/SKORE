package com.xenoage.player.musicxml.note;

import com.xenoage.player.MusicDataElement;
import com.xenoage.player.util.Parser;
import com.xenoage.player.util.XMLReader;

import org.w3c.dom.Element;


/**
 * Note element (version 1.1).
 * 
 * A note can be a grace note, a cue note or a normal note.
 * 
 * A note can be part of a chord, and it is pitched
 * (normal note), unpitched (e.g. percussion)
 * or it is a rest.
 * 
 * It may belong to a certain instrument.
 * 
 * The elements footnote, level, voice, type, dot,
 * accidental, time-modification, stem, notehead,
 * staff, beam, notations and lyric are ignored.
 * 
 * The attributes related to printing are ignored too.
 *
 * @author Andreas Wenger
 */
public class Note
  implements MusicDataElement
{
  
  private NoteType noteType; //grace, cue or normal note
  private String instrument;
  private Float dynamics;
  private Float endDynamics;
  private Float attack;
  private Float release;
  private Integer timeOnly;
  private Boolean pizzicato;
  
  
  public Note(Element e)
  {
    if (XMLReader.element(e, "grace") != null)
      noteType = new GraceNote(e);
    else if (XMLReader.element(e, "cue") != null)
      noteType = new CueNote(e);
    else
      noteType = new NormalNote(e);
    Element eInstrument = XMLReader.element(e, "instrument");
    if (eInstrument != null)
      instrument = XMLReader.attribute(eInstrument, "id");
    dynamics = Parser.parseFloatNull(XMLReader.attribute(e, "dynamics"));
    endDynamics = Parser.parseFloatNull(XMLReader.attribute(e, "end-dynamics"));
    attack = Parser.parseFloatNull(XMLReader.attribute(e, "attack"));
    release = Parser.parseFloatNull(XMLReader.attribute(e, "release"));
    timeOnly = Parser.parseIntegerNull(XMLReader.attribute(e, "time-only"));
    pizzicato = Parser.parseBooleanNull(XMLReader.attribute(e, "pizzicato"));
  }

  
  public Float getAttack()
  {
    return attack;
  }

  
  public Float getDynamics()
  {
    return dynamics;
  }

  
  public Float getEndDynamics()
  {
    return endDynamics;
  }

  
  public String getInstrument()
  {
    return instrument;
  }

  
  public NoteType getNoteType()
  {
    return noteType;
  }

  
  public Boolean getPizzicato()
  {
    return pizzicato;
  }

  
  public Float getRelease()
  {
    return release;
  }

  
  public Integer getTimeOnly()
  {
    return timeOnly;
  }
  

}
