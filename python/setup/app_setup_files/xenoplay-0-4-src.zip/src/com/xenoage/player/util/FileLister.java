package com.xenoage.player.util;

import java.util.ArrayList;
import java.io.*;


/**
 * This class helps to list files from a directory
 * and its subdirectories.
 *
 * @author Andreas Wenger
 */
public class FileLister
{

  public static ArrayList listFile(File dir, boolean bSubdirs, String extension)
  {
    ArrayList list = new ArrayList();
    Process(list, dir, bSubdirs, extension);
    return list;
  }


  private static void Process(ArrayList list, File dir,
    boolean bSubdirs, String extension)
  {
    File[] children = dir.listFiles();
    if (children != null)
    {
      for (int i = 0; i < children.length; i++)
      {
        if (children[i].isDirectory() && bSubdirs)
          Process(list, children[i], bSubdirs, extension);
        else if (children[i].getName().toLowerCase().endsWith(extension.toLowerCase())
          && !children[i].isDirectory())
          list.add(children[i]);
      }
    }
  }

}
