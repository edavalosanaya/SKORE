package com.xenoage.player.musicxml.opus;

import com.xenoage.player.musicxml.MusicXMLContainer;
import com.xenoage.player.util.XMLReader;
import com.xenoage.player.util.io.iocontext.IOContext;
import com.xenoage.player.util.io.iocontext.JarIOContext;
import com.xenoage.player.util.musicxml.FileFormatTools;
import com.xenoage.player.util.musicxml.FileFormatTools.Format;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Element;


/**
 * This class contains only a link to a
 * score within an opus document.
 * 
 * 
 * 
 * This class is compatible to both
 * MusicXML 1.x and 2.0.
 *
 * @author Andreas Wenger
 */
public class OpusScore
  implements OpusChild
{
 
  private IOContext baseIOContext;
  private String filename;
  
  
  /**
   * Reads an opus from the given file behind
   * the given IOContext.
   */
  public OpusScore(Element eScore, IOContext baseIOContext)
    throws IllegalArgumentException
  {
    String filename = XMLReader.attribute(eScore, "xlink:href");
    if (filename != null)
    {
      this.filename = filename;
      this.baseIOContext = baseIOContext;
    }
    else
    {
      throw new IllegalArgumentException("score has no xlink:href");
    }
  }
  
  
  /**
   * Returns this score.
   */
  public List<OpusScore> getScores()
  {
    ArrayList<OpusScore> ret = new ArrayList<OpusScore>(1);
    ret.add(this);
    return ret;
  }
  
  
  /**
   * Returns an InputStream for this score.
   */
  public InputStream open()
    throws IOException
  {
    Format format = FileFormatTools.getFormat(filename);
    if (format == Format.XML)
    {
      //XML score
      return baseIOContext.openFile(filename);
    }
    else if (format == Format.Compressed)
    {
      //MXL score: open rootfile
      JarIOContext jarIO = baseIOContext.openJar(filename);
      MusicXMLContainer container = new MusicXMLContainer(jarIO);
      List<String> files = container.getFiles();
      if (files.size() == 0)
        throw new IOException("Container has no rootfile: " + filename);
      return container.openFile(files.get(0));
    }
    else
    {
      throw new IOException("Unknown format: " + filename);
    }
  }
  
  
  public String getFilename()
  {
    return filename;
  }
  
  
  /**
   * toString: return filename.
   */
  @Override public String toString()
  {
    return getFilename();
  }

}
