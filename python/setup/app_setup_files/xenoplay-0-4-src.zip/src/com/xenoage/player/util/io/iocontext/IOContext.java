package com.xenoage.player.util.io.iocontext;

import java.io.IOException;
import java.io.InputStream;


/**
 * IOContext interface.
 * 
 * An IOContext is an abstract interface to
 * open files from different bases, e.g.
 * from local harddrivers, remote webservers
 * or out from zipped files.
 * 
 * It remembers it path or URL, so it can
 * be used several times, which is especially
 * useful for complicated structures, like
 * files within a zipped file within another
 * zipped file.
 *
 * @author Andreas Wenger
 */
public interface IOContext
{
  
  /**
   * Opens the file with the given filename
   * as an InputStream.
   */
  public InputStream openFile(String filename)
    throws IOException;
  
  
  /**
   * Creates a new JarContentIOContext from the Jar file
   * with the given filename.
   */
  public JarIOContext openJar(String filename)
    throws IOException;

}
