package com.xenoage.player.musicxml.note;


/**
 * The unpitched element indicates musical elements that
 * lack definite pitch, such as unpitched percussion
 * and speaking voice (version 1.1).
 * 
 * The elements display-step and display-octave are
 * ignored.
 *
 * @author Andreas Wenger
 */
public class Unpitched
  implements NotePitchType
{

}
