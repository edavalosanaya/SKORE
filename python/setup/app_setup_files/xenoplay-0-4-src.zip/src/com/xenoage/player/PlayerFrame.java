package com.xenoage.player;

import com.xenoage.player.musicxml.MusicXMLDocument;
import com.xenoage.player.util.*;
import com.xenoage.player.util.io.iocontext.*;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import java.util.TimerTask;

import javax.sound.midi.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


/**
 * The main frame of the Xenoage Player
 * application.
 * 
 * Java 1.5.0 or later is required.
 *
 * @author Andreas Wenger
 */
public class PlayerFrame
  extends JFrame
  implements ActionListener
{
  

  private JMenuBar mnuBar;
  private JMenu mnuFile;
  private JMenuItem mnuFileOpen, mnuFileSave, mnuFileInfo, mnuFileExit;
  private JMenu mnuConvert;
  private JMenuItem mnuConvertFile, mnuConvertDir;
  private JMenu mnuHelp;
  private JMenuItem mnuHelpReadme, mnuHelpAbout;

  private JLabel lblTitle;
  private JProgressBar progress;

  private JButton btnOpen, btnPlay, btnPause, btnStop, btnSave, btnInfo;

  private JSlider sldVolume;

  private MusicXMLDocument doc;
  private Player player;
  
  private String lastPath;

  private java.util.Timer timer;


  public PlayerFrame()
  {
    this.player = new Player(this);
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    this.setMinimumSize(new Dimension(380, 135));
    this.setLocationRelativeTo(null);
    try
    {
      this.setIconImage(new ImageIcon("data/images/icon.png").getImage());
    }
    catch (Exception ex)
    {
    }
    this.setTitle(Player.APP_TITLE);
    this.setResizable(false);

    mnuBar = new JMenuBar();

    mnuFile = new JMenu("File");
    mnuBar.add(mnuFile);
    mnuFileOpen = new JMenuItem("Open...");
    mnuFileOpen.addActionListener(this);
    mnuFile.add(mnuFileOpen);
    mnuFileSave = new JMenuItem("Save as...");
    mnuFileSave.addActionListener(this);
    mnuFile.add(mnuFileSave);
    mnuFile.addSeparator();
    mnuFileInfo = new JMenuItem("Show info...");
    mnuFileInfo.addActionListener(this);
    mnuFile.add(mnuFileInfo);
    mnuFile.addSeparator();
    mnuFileExit = new JMenuItem("Exit");
    mnuFileExit.addActionListener(this);
    mnuFile.add(mnuFileExit);

    mnuConvert = new JMenu("Convert");
    mnuBar.add(mnuConvert);
    mnuConvertFile = new JMenuItem("File to Midi...");
    mnuConvertFile.addActionListener(this);
    mnuConvert.add(mnuConvertFile);
    mnuConvertDir = new JMenuItem("Directory to Midi...");
    mnuConvertDir.addActionListener(this);
    mnuConvert.add(mnuConvertDir);

    mnuHelp = new JMenu("Help");
    mnuBar.add(mnuHelp);
    mnuHelpReadme = new JMenuItem("Readme...");
    mnuHelpReadme.addActionListener(this);
    mnuHelp.add(mnuHelpReadme);
    mnuHelp.addSeparator();
    mnuHelpAbout = new JMenuItem("About...");
    mnuHelpAbout.addActionListener(this);
    mnuHelp.add(mnuHelpAbout);


    this.setJMenuBar(mnuBar);
    
    int border = 4;
    
    FlowLayout contentPaneLayout = new FlowLayout(
      FlowLayout.CENTER, border, border);
    this.getContentPane().setLayout(contentPaneLayout);
    
    JPanel mainPanel = new JPanel();
    mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
    this.add(mainPanel);

    JPanel pnlTitle = new JPanel();
    pnlTitle.setBorder(BorderFactory.createEmptyBorder(
      border, border, border, border));
    pnlTitle.setLayout(new GridLayout(1, 1));
    mainPanel.add(pnlTitle);
    
    lblTitle = new JLabel(" ");
    pnlTitle.add(lblTitle);

    JPanel pnlProgress = new JPanel();
    pnlProgress.setBorder(BorderFactory.createEmptyBorder(
      border, border, border, border));
    pnlProgress.setLayout(new GridLayout(1, 1));
    mainPanel.add(pnlProgress);
    
    progress = new JProgressBar();
    progress.setMaximum(1000);
    progress.setString("00:00 / 00:00");
    progress.setStringPainted(true);
    progress.addMouseListener(new MouseAdapter()
    {
      @Override public void mousePressed(MouseEvent e)
      {
        try
        {
          Sequencer sequencer = player.getSequencer();
          sequencer.setMicrosecondPosition(
            sequencer.getMicrosecondLength() * e.getX() / progress.getWidth());
        }
        catch (Exception ex)
        {
        }
      }
    });
    pnlProgress.add(progress);
    
    FlowLayout buttonsLayout = new FlowLayout(
      FlowLayout.CENTER, border / 2, border);
    JPanel pnlButtons = new JPanel(buttonsLayout);
    mainPanel.add(pnlButtons);

    btnOpen = new JButton(new ImageIcon("data/images/open.png"));
    btnOpen.setPreferredSize(new Dimension(22, 22));
    btnOpen.addMouseListener(new MouseAdapter()
    {
      @Override public void mouseClicked(MouseEvent e)
      {
        OpenFile();
      }
    });
    pnlButtons.add(btnOpen);

    btnPlay = new JButton(new ImageIcon("data/images/play.png"));
    btnPlay.setPreferredSize(new Dimension(22, 22));
    btnPlay.addMouseListener(new MouseAdapter()
    {
      @Override public void mouseClicked(MouseEvent e)
      {
        player.play();
      }
    });
    pnlButtons.add(btnPlay);

    btnPause = new JButton(new ImageIcon("data/images/pause.png"));
    btnPause.setPreferredSize(new Dimension(22, 22));
    btnPause.addMouseListener(new MouseAdapter()
    {
      @Override public void mouseClicked(MouseEvent e)
      {
        player.pause();
      }
    });
    pnlButtons.add(btnPause);

    btnStop = new JButton(new ImageIcon("data/images/stop.png"));
    btnStop.setPreferredSize(new Dimension(22, 22));
    btnStop.addMouseListener(new MouseAdapter()
    {
      @Override public void mouseClicked(MouseEvent e)
      {
        player.stop();
      }
    });
    pnlButtons.add(btnStop);

    JLabel lblVolume = new JLabel(new ImageIcon("data/images/volume.png"));
    lblVolume.setPreferredSize(new Dimension(22, 22));
    pnlButtons.add(lblVolume);

    sldVolume = new JSlider(JSlider.HORIZONTAL, 0, 100,
      (int) (player.getVolume() * 100));
    sldVolume.setPaintLabels(false);
    sldVolume.setMajorTickSpacing(1);
    sldVolume.setMinorTickSpacing(1);
    sldVolume.setPaintTicks(false);
    sldVolume.setMinimumSize(new Dimension(200, 22));
    sldVolume.addChangeListener(new sldVolumeListener());
    pnlButtons.add(sldVolume);

    btnSave = new JButton(new ImageIcon("data/images/save.png"));
    btnSave.setPreferredSize(new Dimension(22, 22));
    btnSave.addMouseListener(new MouseAdapter()
    {
      @Override public void mouseClicked(MouseEvent e)
      {
        SaveMidiFile();
      }
    });
    pnlButtons.add(btnSave);

    btnInfo = new JButton(new ImageIcon("data/images/info.png"));
    btnInfo.setPreferredSize(new Dimension(22, 22));
    btnInfo.addMouseListener(new MouseAdapter()
    {
      @Override public void mouseClicked(MouseEvent e)
      {
        showInfoWindow(0);
      }
    });
    pnlButtons.add(btnInfo);
    
    this.pack();

  }


  public void OpenFile()
  {
    try
    {
      if (lastPath == null)
        lastPath = "files/";
      JFileChooser fc = new JFileChooser(lastPath);
      fc.addChoosableFileFilter(new MusicXMLFilter());
      int ret = fc.showOpenDialog(this);
      if (ret == JFileChooser.APPROVE_OPTION)
      {
        File file = fc.getSelectedFile();
        lastPath = file.getAbsolutePath();
        
        String dir = file.getParent();
        if (dir == null)
          dir = "";
        doc = player.openDocument(
          new FileIOContext(dir), file.getName(), this);
                
        if (doc != null)
        {
          player.openDocument(doc);
          String creator = MusicXMLDocumentInfo.getComposer(doc);
          if (creator.length() > 1)
            creator += " - ";
          lblTitle.setText("<html><b>" + creator
            + MusicXMLDocumentInfo.getScoreTitle(doc) + "</b></html>");
    
          timer = new java.util.Timer();
          timer.scheduleAtFixedRate(new Task(), 0, 10);
          
          player.play();
        }
        
        this.pack();
      }
    }
    catch (Exception ex)
    {
      MsgBox("Could not open MusicXML file!\n" +
        "See the about dialog for more information.", JOptionPane.ERROR_MESSAGE);
      ex.printStackTrace();
    }
  }


  public void SaveMidiFile()
  {
    Sequence seq = player.getSequencer().getSequence();
    if (seq == null)
    {
      MsgBox("Please load a file first!", JOptionPane.WARNING_MESSAGE);
      return;
    }
    JFileChooser fc = new JFileChooser(lastPath);
    fc.addChoosableFileFilter(new MidiFilter());
    fc.setAcceptAllFileFilterUsed(false);
    String defaultFileName = new File(lastPath).getName();
    if (defaultFileName.toLowerCase().endsWith(".xml"))
      defaultFileName = defaultFileName.substring(0, defaultFileName.length() - 4)
        + ".mid";
    else
      defaultFileName += ".mid";
    fc.setSelectedFile(new File(defaultFileName));
    int ret = fc.showSaveDialog(this);
    if (ret == JFileChooser.APPROVE_OPTION)
    {
      File file = fc.getSelectedFile();
      lastPath = file.getAbsolutePath();
      try
      {
        MidiSystem.write(seq, 1, file);
      }
      catch (Exception ex)
      {
        MsgBox("Error while saving Midi file!", JOptionPane.ERROR_MESSAGE);
      }
    }
  }


  public void ConvertToMidiFile()
  {
    try
    {
      if (lastPath == null)
        lastPath = "files/";
      JFileChooser fc = new JFileChooser(lastPath);
      fc.addChoosableFileFilter(new MusicXMLFilter());
      int ret = fc.showOpenDialog(this);
      if (ret == JFileChooser.APPROVE_OPTION)
      {
        File file = fc.getSelectedFile();
        lastPath = file.getAbsolutePath();
        String dir = file.getParent();
        if (dir == null)
          dir = "";
        MusicXMLDocument docConv = player.openDocument(
          new FileIOContext(dir), file.getName(), this);
        Sequence seqConv = MusicXMLtoMIDI.convertMusicXMLtoMIDI(docConv, player);
        if (seqConv == null)
        {
          MsgBox("Error while loading MusicXML file!", JOptionPane.ERROR_MESSAGE);
        }
        else
        {
          String newPath = lastPath;
          if (newPath.toLowerCase().endsWith(".xml") ||
            newPath.toLowerCase().endsWith(".mxl"))
            newPath = newPath.substring(0, newPath.length() - 4) + ".mid";
          else
            newPath += ".mid";
          try
          {
            MidiSystem.write(seqConv, 1, new File(newPath));
          }
          catch (Exception ex)
          {
            MsgBox("Error while saving Midi file!", JOptionPane.ERROR_MESSAGE);
          }
        }
      }
    }
    catch (Exception ex)
    {
      MsgBox("Could not convert to Midi file!", JOptionPane.ERROR_MESSAGE);
      ex.printStackTrace();
    }
  }


  public void ConvertToMidiDir()
  {
    try
    {
      if (lastPath == null)
        lastPath = "files/";
      JFileChooser fc = new JFileChooser(lastPath);
      fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
      JCheckBox chkSubdir = new JCheckBox("Include subdirectories", true);
      JCheckBox chkOnlyXml = new JCheckBox("Only \".xml\" files", true);
      JCheckBox chkCancel = new JCheckBox("Cancel at first error", false);
      JPanel pnlOptions = new JPanel();
      pnlOptions.setLayout(new BoxLayout(pnlOptions, BoxLayout.Y_AXIS));
      pnlOptions.add(chkSubdir);
      pnlOptions.add(chkOnlyXml);
      pnlOptions.add(chkCancel);
      fc.setAccessory(pnlOptions);
      int ret = fc.showOpenDialog(this);
      if (ret == JFileChooser.APPROVE_OPTION)
      {
        File dir = fc.getSelectedFile();
        lastPath = dir.getAbsolutePath();
        String ext = "";
        if (chkOnlyXml.isSelected())
          ext = ".xml";
        ArrayList files = FileLister.listFile(dir, chkSubdir.isSelected(), ext);
        MusicXMLDocument docConv;
        Sequence seqConv;
        int countOK = 0, countFailed = 0;
        for (int i = 0; i < files.size(); i++)
        {
          File curFile = ((File) files.get(i));
          String curPath = curFile.getAbsolutePath();
          String curDir = curFile.getParent();
          if (curDir == null)
            curDir = "";
          docConv = player.openDocument(
            new FileIOContext(curDir), curFile.getName(), this);
          seqConv = MusicXMLtoMIDI.convertMusicXMLtoMIDI(docConv, player);
          if (seqConv == null)
          {
            if (chkCancel.isSelected())
            {
              MsgBox("Error while loading MusicXML file!", JOptionPane.ERROR_MESSAGE);
              return;
            }
            else
            {
              countFailed++;
            }
          }
          else
          {
            if (curPath.toLowerCase().endsWith(".xml"))
              curPath = curPath.substring(0, curPath.length() - 4) + ".mid";
            else
              curPath += ".mid";
            try
            {
              MidiSystem.write(seqConv, 1, new File(curPath));
              countOK++;
            }
            catch (Exception ex)
            {
              if (chkCancel.isSelected())
              {
                MsgBox("Error while saving Midi file!", JOptionPane.ERROR_MESSAGE);
                return;
              }
              else
              {
                countFailed++;
              }
            }
          }
        }
  
        MsgBox("Conversion complete.\nConverted files: " + String.valueOf(countOK)
          + "\nErrors: " + String.valueOf(countFailed), JOptionPane.INFORMATION_MESSAGE);
  
      }
    }
    catch (Exception ex)
    {
      MsgBox("Could not convert to Midi files!", JOptionPane.ERROR_MESSAGE);
      ex.printStackTrace();
    }
  }


  public void showInfoWindow(int TabIndex)
  {
    InfoWindow frmInfo = new InfoWindow();
    frmInfo.setInformation(doc);
    frmInfo.setActivePage(TabIndex);
    frmInfo.setConsoleOutput(player.getConsoleOutput());
    frmInfo.setVisible(true);
  }


  public void actionPerformed(ActionEvent e)
  {
    if (e.getSource() == mnuFileOpen)
      OpenFile();
    else if (e.getSource() == mnuFileSave)
      SaveMidiFile();
    else if (e.getSource() == mnuFileInfo)
      showInfoWindow(0);
    else if (e.getSource() == mnuFileExit)
      System.exit(0);
    else if (e.getSource() == mnuConvertFile)
      ConvertToMidiFile();
    else if (e.getSource() == mnuConvertDir)
      ConvertToMidiDir();
    else if (e.getSource() == mnuHelpReadme)
      MsgBox("Read readme.txt for more information.", JOptionPane.INFORMATION_MESSAGE);
    else if (e.getSource() == mnuHelpAbout)
      showInfoWindow(1);
  }


  public void MsgBox(String Msg, int MsgType)
  {
    JOptionPane.showMessageDialog(this, Msg, Player.APP_TITLE, MsgType);
  }


  public String getTime(int time)
  {
    String mins, secs;
    mins = String.valueOf(time / 60);
    secs = String.valueOf(time % 60);
    if (secs.length() < 2)
      secs = "0" + secs;
    return mins + ":" + secs;
  }


  public static void main(String[] args)
  {
    try
    {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }
    catch (Exception ex)
    {
    }

    PlayerFrame frmMain = new PlayerFrame();
    frmMain.setVisible(true);
  }


  private class MusicXMLFilter
    extends javax.swing.filechooser.FileFilter
  {
    
    @Override public boolean accept(File f)
    {
      if (f.isDirectory())
        return true;
      if (f.toString().toLowerCase().endsWith(".xml"))
        return true;
      if (f.toString().toLowerCase().endsWith(".mxl"))
        return true;
      return false;
    }


    @Override public String getDescription()
    {
      return "MusicXML files (.mxl, .xml)";
    }
  }


  private class MidiFilter
    extends javax.swing.filechooser.FileFilter
  {

    @Override public boolean accept(File f)
    {
      if (f.isDirectory())
        return true;
      if (f.toString().toLowerCase().endsWith(".mid"))
        return true;
      return false;
    }


    @Override public String getDescription()
    {
      return "MIDI files (.mid)";
    }
  }


  private class Task
    extends TimerTask
  {

    @Override public void run()
    {
      try
      {
        Sequencer sequencer = player.getSequencer();
        progress.setValue((int) (sequencer.getMicrosecondPosition() * 1000 / sequencer
          .getMicrosecondLength()));
        progress.setString(getTime((int) (sequencer.getMicrosecondPosition() / 1000000))
          + " / " + getTime((int) (sequencer.getMicrosecondLength() / 1000000)));

      }
      catch (Exception e)
      {
      }
    }
  }

  
  private class sldVolumeListener
    implements ChangeListener
  {

    public void stateChanged(ChangeEvent e)
    {
      player.setVolume(0.01f * sldVolume.getValue());
    }
  }


}
