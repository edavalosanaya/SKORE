package com.xenoage.player.musicxml.identity;

import com.xenoage.player.util.XMLReader;

import org.w3c.dom.Element;


/**
 * Encoder of a MusicXML file (version 1.1).
 *
 * @author Andreas Wenger
 */
public class Encoder
{
  
  private String value;
  private String type;
  
  
  public Encoder(Element e)
  {
    value = XMLReader.textTrim(e);
    type = XMLReader.attribute(e, "type");
  }


  public String getValue()
  {
    return value;
  }
  
  
  /**
   * Gets the type of encoder, or null if unknown.
   */
  public String getType()
  {
    return type;
  }
  

}
