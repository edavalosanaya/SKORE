package com.xenoage.player.musicxml.note;


/**
 * This element indicates that this note is an
 * additional chord tone with the preceding note
 * (version 1.1).
 *
 * @author Andreas Wenger
 */
public class Chord
{

}
