package com.xenoage.player.util.io.iocontext;

import java.io.*;


/**
 * IOContext for access to the contents
 * of a Jar file.
 * 
 * The filenames are relative to the root
 * folder of the Jar file.
 *
 * @author Andreas Wenger
 */
public class JarFileIOContext
  extends JarIOContext
{
  
  private File jarFile;
  
  
  /**
   * Creates an URLIOContext for the given Jar file.
   */
  public JarFileIOContext(File jarFile)
  {
    this.jarFile = jarFile;
  }
  
  
  /**
   * Opens an input stream for this Jar document.
   */
  @Override public InputStream open()
    throws IOException
  {
    return new FileInputStream(jarFile);
  }
  

}
