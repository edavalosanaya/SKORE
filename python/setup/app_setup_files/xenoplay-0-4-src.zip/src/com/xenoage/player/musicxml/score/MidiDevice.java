package com.xenoage.player.musicxml.score;

import com.xenoage.player.util.Parser;
import com.xenoage.player.util.XMLReader;

import org.w3c.dom.Element;


/**
 * Element for the DeviceName meta event
 * in Standard MIDI Files (version 1.1).
 *
 * @author Andreas Wenger
 */
public class MidiDevice
{
  
  private String value;
  private Integer port;
  
  
  public MidiDevice(Element e)
  {
    value = XMLReader.textTrim(e);
    String attr = XMLReader.attribute(e, "port");
    if (attr != null)
      port = Parser.parseInt(attr);
  }


  public String getValue()
  {
    return value;
  }
  
  
  /**
   * Gets the port of the midi device, or null if unknown.
   */
  public Integer getPort()
  {
    return port;
  }
  

}
