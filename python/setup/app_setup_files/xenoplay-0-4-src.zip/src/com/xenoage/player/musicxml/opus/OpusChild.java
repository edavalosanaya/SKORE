package com.xenoage.player.musicxml.opus;

import java.util.List;


/**
 * Interface for all childs an opus can have.
 *
 * @author Andreas Wenger
 */
public interface OpusChild
{
  
  /**
   * Gets the list of all scores of this opus child
   * in the correct order.
   */
  public List<OpusScore> getScores();

}
