package com.xenoage.player.musicxml.score;

import com.xenoage.player.MusicDataElement;
import com.xenoage.player.musicxml.attributes.Attributes;
import com.xenoage.player.musicxml.direction.Direction;
import com.xenoage.player.musicxml.direction.Sound;
import com.xenoage.player.musicxml.note.*;
import com.xenoage.player.util.XMLReader;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Element;


/**
 * Class for a measure within a
 * partwise score (version 1.1).
 * 
 * The elements harmony, figured-bass,
 * print, barline, grouping, link and bookmark
 * are ignored.
 * 
 * The implicit, non-controlling and
 * width attributes are ignored, too.
 *
 * @author Andreas Wenger
 */
public class Measure
{
  
  private String id;
  private ArrayList<MusicDataElement> musicDataElements;
  
  
  public Measure(Element e)
  {
    id = XMLReader.attribute(e, "id");
    musicDataElements = new ArrayList<MusicDataElement>();
    List<Element> eElements = XMLReader.elements(e);
    for (Element eElement : eElements)
    {
      String name = eElement.getNodeName();
      //note
      if (name.equals("note"))
        musicDataElements.add(new Note(eElement));
      //backup
      else if (name.equals("backup"))
        musicDataElements.add(new Backup(eElement));
      //forward
      else if (name.equals("forward"))
        musicDataElements.add(new Forward(eElement));
      //direction
      else if (name.equals("direction"))
        musicDataElements.add(new Direction(eElement));
      //attributes
      else if (name.equals("attributes"))
        musicDataElements.add(new Attributes(eElement));
      //sound
      else if (name.equals("sound"))
        musicDataElements.add(new Sound(eElement));
    }
  }

  
  public String getId()
  {
    return id;
  }

  
  public List<MusicDataElement> getMusicDataElements()
  {
    return musicDataElements;
  }

}
