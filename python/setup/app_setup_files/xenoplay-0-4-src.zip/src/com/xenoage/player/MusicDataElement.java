package com.xenoage.player;


/**
 * Interface for the elements that
 * are used within a measure.
 *
 * @author Andreas Wenger
 */
public interface MusicDataElement
{

}
