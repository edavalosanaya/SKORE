package com.xenoage.player.musicxml.note;


/**
 * Type of a note.
 * 
 * This interface models the code
 * <code>
 * (grace, %full-note;, (tie, tie?)?) |
 * (cue, %full-note;, duration) |
 * (%full-note;, duration, (tie, tie?)?)
 * </code>
 * in the note element in MusicXML 1.1.
 * 
 * The three types are modeled as the three
 * classes GraceNote, CueNote and NormalNote.
 *
 * @author Andreas Wenger
 */
public interface NoteType
{
  
  public Chord getChord();
  
  public NotePitchType getNotePitchType();
  
  public Duration getDuration();
  
  public void setDuration(Duration duration);

}
