package com.xenoage.player.musicxml.note;


/**
 * Type of the pitch of a note.
 * 
 * This interface models the code
 * <code>
 * (pitch | unpitched | rest)
 * </code>
 * in the full-note entity in MusicXML 1.1.
 *
 * @author Andreas Wenger
 */
public interface NotePitchType
{

}
