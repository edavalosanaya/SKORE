package com.xenoage.player.musicxml.note;


/**
 * The rest element indicates notated rests
 * or silences (version 1.1).
 * 
 * The elements display-step and display-octave are
 * ignored.
 *
 * @author Andreas Wenger
 */
public class Rest
  implements NotePitchType
{

}
