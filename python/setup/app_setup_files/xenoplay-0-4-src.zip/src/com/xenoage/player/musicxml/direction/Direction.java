package com.xenoage.player.musicxml.direction;

import com.xenoage.player.MusicDataElement;
import com.xenoage.player.util.XMLReader;

import org.w3c.dom.Element;


/**
 * Direction element (version 1.1).
 * 
 * All elements and attributes are not supported,
 * except the sound element.
 *
 * @author Andreas Wenger
 */
public class Direction
  implements MusicDataElement
{
  
  private Sound sound;
  
  
  public Direction(Element e)
  {
    Element eSound = XMLReader.element(e, "sound");
    if (eSound != null)
      sound = new Sound(eSound);
  }


  public Sound getSound()
  {
    return sound;
  }
}
