package com.xenoage.player.musicxml.note;

import com.xenoage.player.util.XMLReader;

import org.w3c.dom.Element;


/**
 * Cue note.
 * 
 * This class models the code
 * <code>
 * (cue, %full-note;, duration)
 * </code>
 * in the note element in MusicXML 1.1.
 * 
 * The element cue is ignored.
 *
 * @author Andreas Wenger
 */
public class CueNote
  implements NoteType
{
  
  private Chord chord;
  private NotePitchType notePitchType;
  private Duration duration;
  
  
  public CueNote(Element e)
  {
    if (XMLReader.element(e, "chord") != null)
      chord = new Chord();
    Element ePitch = XMLReader.element(e, "pitch");
    Element eUnpitched = XMLReader.element(e, "unpitched");
    Element eRest = XMLReader.element(e, "rest");
    if (ePitch != null)
      notePitchType = new Pitch(ePitch);
    else if (eUnpitched != null)
      notePitchType = new Unpitched();
    else if (eRest != null)
      notePitchType = new Rest();
    duration = new Duration(XMLReader.element(e, "duration"));
  }

  
  public Chord getChord()
  {
    return chord;
  }

  
  public NotePitchType getNotePitchType()
  {
    return notePitchType;
  }

  
  public Duration getDuration()
  {
    return duration;
  }
  
  
  public void setDuration(Duration duration)
  {
    this.duration = duration;
  }
  

}
