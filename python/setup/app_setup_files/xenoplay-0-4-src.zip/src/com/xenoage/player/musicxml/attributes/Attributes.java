package com.xenoage.player.musicxml.attributes;

import com.xenoage.player.MusicDataElement;
import com.xenoage.player.util.Parser;
import com.xenoage.player.util.XMLReader;

import org.w3c.dom.Element;


/**
 * The attributes element contains musical information
 * that typically changes on measure boundaries
 * (version 1.1).
 * 
 * All elements except divisions and transpose are
 * ignored.
 *
 * @author Andreas Wenger
 */
public class Attributes
  implements MusicDataElement
{
  
  private Integer divisions;
  private Transpose transpose;
  
  
  public Attributes(Element e)
  {
    divisions = Parser.parseIntegerNull(XMLReader.elementText(e, "divisions"));
    Element eTranspose = XMLReader.element(e, "transpose");
    if (eTranspose != null)
      transpose = new Transpose(eTranspose);
  }

  
  public Integer getDivisions()
  {
    return divisions;
  }
  
  
  public void setDivisions(Integer divisions)
  {
    this.divisions = divisions;
  }

  
  public Transpose getTranspose()
  {
    return transpose;
  }
  

}
