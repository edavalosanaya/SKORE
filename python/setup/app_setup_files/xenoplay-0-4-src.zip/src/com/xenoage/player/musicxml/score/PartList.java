package com.xenoage.player.musicxml.score;

import com.xenoage.player.util.XMLReader;

import java.util.*;

import org.w3c.dom.Element;


/**
 * Information about the musical parts in this
 * score (version 1.1).
 * 
 * The part-group element is not supported.
 *
 * @author Andreas Wenger
 */
public class PartList
{
  
  private ArrayList<ScorePart> scoreParts;
  
  
  public PartList(Element e)
  {
    scoreParts = new ArrayList<ScorePart>();
    List<Element> eScoreParts = XMLReader.elements(e, "score-part");
    for (Element eScorePart : eScoreParts)
    {
      scoreParts.add(new ScorePart(eScorePart));
    }
  }

  
  public List<ScorePart> getScoreParts()
  {
    return scoreParts;
  }

  
}
