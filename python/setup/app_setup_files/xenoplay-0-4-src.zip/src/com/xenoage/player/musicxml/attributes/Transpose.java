package com.xenoage.player.musicxml.attributes;

import com.xenoage.player.util.Parser;
import com.xenoage.player.util.XMLReader;

import org.w3c.dom.Element;


/**
 * If the part is being encoded for a transposing instrument
 * in written vs. concert pitch, the transposition must be
 * encoded in the transpose element (version 1.1).
 * 
 * The elements diatonic and double are ignored.
 *
 * @author Andreas Wenger
 */
public class Transpose
{
  
  private int chromatic;
  private Integer octaveChange;
  
  
  public Transpose(Element e)
  {
    chromatic = Parser.parseInt(XMLReader.elementText(e, "chromatic"));
    octaveChange = Parser.parseIntegerNull(XMLReader.elementText(e, "octave-change"));
  }

  
  public int getChromatic()
  {
    return chromatic;
  }

  
  public Integer getOctaveChange()
  {
    return octaveChange;
  }

}
