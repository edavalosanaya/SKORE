
Xenoage Player 0.4
******************

(c) 2004-2007 by Andreas Wenger, Xenoage Software

MusicXML format (c) by Recordare LLC, http://www.recordare.com
Most example MusicXML files are from the "set of musical examples", (c) by Recordare LLC.


MusicXML is a file format developed by Recordare that can be used to exchange files between music notation software like Sibelius, Finale or Igor Engraver.
Xenoage Player is a program written in Java that plays MusicXML files and allows to save them as Standard MIDI Files. It is free for both personal and commercial use and is currently available as a standalone application and an applet for webpages. At the moment the Xenoage Player is still in beta stage.
Detailed information on MusicXML can be found on the official Website http://www.musicxml.org . Visit also our website at http://www.xenoage.com/player/ .

This program is free software and is distributed under the GNU General Public License (GPL). You can find a copy of the license at http://www.fsf.org/licensing/licenses/gpl.html .
If you like this program, please support us with a voluntary donation ( http://www.xenoage.com/donate/ ).



System Requirements
*******************

You need the Java Runtime Environment (J2RE), at least version 1.5.0. You can download it at http://www.java.com .
Doubleclick xenoplay.jar to start the program. If this doesn't work, start it with "java -jar xenoplay.jar".


How to use the applet
*********************

The Xenoage Player can be directly placed on a website as a Java Applet. This guarantees that it works on many operating systems on the client side, like Linux, Windows, MacOS or Solaris.

The installation is easy. You can upload the two files "xenoplay.jar" and "skin.jar" into any directory. The website on which you want to place the applet must be extended by following HTML code:

<applet code="com/xenoage/player/PlayerApplet.class" archive="xenoplay.jar,skin.jar" width="384" height="36">
   <param name="bgcolor" value="FFFFFF">
   <param name="path" value="files/">
   <param name="files" value="score1.xml;score2.xml;score3-container.mxl"> 
   <param name="start" value="score2.xml">	 
</applet>

You can find a webpage using this applet at http://www.xenoage.com/player/sample.html .

The Xenoage Player Applet is skinable. You can create your own skins. Just open the skin.jar file and you will see its structure. To open it, rename it into "skin.zip" and extract it with any compression software. To create your own skin, include all needed files (must be in png-format) in a zip-file and rename it to "skin.jar", replacing the old skin.

If the background image of the skin contains transparency, you can set the background color for these pixels. Just set the "bgcolor"-parameter to any hexadecimal RGB-value.

Please note that the two jar files and the MusicXML files the user can choose between must be placed in the same directory, "files/" in our example, which we have to set in the "path"-parameter. Of course you can place the files in the same directory as the HTML file, in this case the path would be a empty string (""). It is not possible to open files on the user's harddrive. This is no restriction caused by the Xenoage Player but because of security reasons of the Java VM.

The list of the available MusicXML files is given in the "files"-parameter. Separate the files with semicolons (;). It is not possible to let the applet read out the directory automatically, again because of security reasons. But if you want to list for example all ".xml"-files in the directory "your/path/", this could be done with the following PHP-script:

<param name="files" value="<?php

function right ($str, $howManyCharsFromRight)
{
   $strLen = strlen ($str);
   return substr ($str, $strLen - $howManyCharsFromRight, $strLen);
}

$handle=opendir('your/path/');
while ($file = readdir ($handle)) {
   if ($file != "." && $file != ".." && right($file, 4) == ".xml") {
      echo "$file;";
   }
}
closedir($handle);

?>">

Xenoage Player 0.4 or later allows also to load zipped MusicXML files (.mxl). If there is only one score in the file, it is played automatically, otherwise the user is asked which score he wants to play.

The start-argument allows you to set a file that is played immediately after the applet has been loaded.

After these few steps the applet is installed and ready to play the uploaded MusicXML files. If it does not work, first try other Java applets to ensure that Java is installed correctly on your system. After that, read again the above instructions and look if you have set the parameters in the right way, especially the paths.


Problems?
*********

First take a look on the website of this program. You can find the address in the About-box. Then visit the Xenoage Discussion Board at http://www.xenoage.com/forum/ . If you can't find a solution, write an e-mail to info@xenoage.com with a detailled description of the problem. We'll try to help you!



Contact
*******


Andreas Wenger
Peter Rosegger Str. 7
86529 Schrobenhausen
Germany

Homepage: http://www.xenoage.com
E-Mail:   info@xenoage.com


