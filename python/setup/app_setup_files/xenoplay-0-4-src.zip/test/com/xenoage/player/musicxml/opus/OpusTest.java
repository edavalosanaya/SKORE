package com.xenoage.player.musicxml.opus;


import static org.junit.Assert.*;

import com.xenoage.player.util.XMLReader;
import com.xenoage.player.util.io.iocontext.FileIOContext;
import com.xenoage.player.util.io.iocontext.JarFileIOContext;

import java.io.*;
import java.util.List;

import org.junit.Test;
import org.w3c.dom.Document;


/**
 * Test cases for an Opus class.
 *
 * @author Andreas Wenger
 */
public class OpusTest
{
  
  /**
   * Reads an opus document, that contains a score, a nested
   * opus document with two scores and a link to another
   * opus document with another score.
   * Both opus files are opened as normal files. 
   * Check the filenames and the correct order.
   */
  @Test public void testOpusFile()
  {
    try
    {
      //read the opus
      FileIOContext io = new FileIOContext("data/test/");
      InputStream in = io.openFile("SomeOpus.xml");
      Document doc = XMLReader.readFile(in);
      Opus opus = new Opus(doc, io);
      //check the filenames and their order
      List<OpusScore> files = opus.getScores();
      assertEquals(4, files.size());
      assertEquals("BeetAnGeSample.xml", files.get(0).getFilename());
      assertEquals("BrahWiMeSample.mxl", files.get(1).getFilename());
      assertEquals("DebuMandSample.xml", files.get(2).getFilename());
      assertEquals("SchbAvMaSample.xml", files.get(3).getFilename());
    }
    catch (Exception ex)
    {
      fail(ex.toString());
    }
  }
  
  
  /**
   * Reads an opus document, that contains a score, a nested
   * opus document with two scores and a link to another
   * opus document with another score.
   * All files are packed in a single .mxl file. 
   * Check the filenames and the correct order.
   */
  @Test public void testOpusMXL()
  {
    try
    {
      //read the opus
      JarFileIOContext io = new JarFileIOContext(new File("data/test/Album.mxl"));
      InputStream in = io.openFile("Opus.xml");
      Document doc = XMLReader.readFile(in);
      Opus opus = new Opus(doc, io);
      //check the filenames and their order
      List<OpusScore> files = opus.getScores();
      assertEquals(4, files.size());
      assertEquals("BeetAnGeSample.xml", files.get(0).getFilename());
      assertEquals("BrahWiMeSample.mxl", files.get(1).getFilename());
      assertEquals("DebuMandSample.xml", files.get(2).getFilename());
      assertEquals("SchbAvMaSample.xml", files.get(3).getFilename());
    }
    catch (Exception ex)
    {
      fail(ex.toString());
    }
  }

}
