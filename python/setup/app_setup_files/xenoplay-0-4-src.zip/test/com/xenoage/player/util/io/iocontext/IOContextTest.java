package com.xenoage.player.util.io.iocontext;


import static org.junit.Assert.*;

import com.xenoage.player.util.XMLReader;

import java.io.*;

import org.junit.Test;
import org.w3c.dom.Document;


/**
 * Test cases for IOContext implementations.
 *
 * @author Andreas Wenger
 */
public class IOContextTest
{
  
  
  /**
   * Tests the JarFileIOContext and the JarContentIOContext.
   * 
   * root.zip contains node1.zip, node1.zip contains node2.zip,
   * node2.zip contains leaf.xml. leaf.xml is opened.
   */
  @Test public void testNestedZipFiles()
  {
    try
    {
      JarFileIOContext root = new JarFileIOContext(new File("data/test/root.zip"));
      JarContentIOContext node1 = new JarContentIOContext("node1.zip", root);
      JarContentIOContext node2 = new JarContentIOContext("node2.zip", node1);
      InputStream in = node2.openFile("leaf.xml");
      Document doc = XMLReader.readFile(in);
      assertEquals("score-partwise", XMLReader.root(doc).getNodeName());
    }
    catch (Exception ex)
    {
      fail(ex.toString());
    }
  }
  

}
